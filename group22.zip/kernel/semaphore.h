struct semaphore {
    int num;
    struct cond_t cv;
    struct sleeplock lk;
};