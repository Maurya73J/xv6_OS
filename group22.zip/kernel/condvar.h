struct cond_t {
  struct sleeplock lk; // spinlock protecting this sleep lock
  // For debugging:
  char *name;        // Name of lock.
};