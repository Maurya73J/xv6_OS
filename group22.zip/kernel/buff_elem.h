struct buff_elem {
    int val;
    int full;
    struct sleeplock lock;
    struct cond_t cond_insert;
    struct cond_t cond_delete;
};