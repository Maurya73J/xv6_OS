#include "types.h"
#include "riscv.h"
#include "defs.h"
#include "param.h"
#include "memlayout.h"
#include "spinlock.h"
#include "proc.h"
#include "sleeplock.h"
#include "condvar.h"
#include "semaphore.h"

void sem_init(struct semaphore *sem, int x)
{
    cond_init(&sem->cv, "sem_cv");
    initsleeplock(&sem->lk, "sem_lock");
    sem->num = x;
}
void sem_wait(struct semaphore *sem)
{
    acquiresleep(&sem->lk);
    while(sem->num<=0)
    {
        cond_wait(&sem->cv,&sem->lk);
    }
    sem->num--;
    releasesleep(&sem->lk);
}
void sem_post(struct semaphore *sem)
{
    acquiresleep(&sem->lk);
    sem->num++;
    cond_signal(&sem->cv);
    releasesleep(&sem->lk);
}